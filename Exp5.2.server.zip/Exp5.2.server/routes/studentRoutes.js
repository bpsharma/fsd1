const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

// CREATE: Insert a new Student
router.post('/', async (req, res) => {
  try {
    const s = new Student(req.body);
    const saved = await s.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// READ: Get all books
router.get('/', async (req, res) => {
  const students = await Student.find();
  res.json(students);
});

// READ: Get a specific student record for given rollno
router.get('/:rollno', async (req, res) => {
  try {
    const s = await Student.findOne({ rollno: req.params.rollno });
    if (!s) return res.status(404).json({ error: "Student not found" });
    res.json(s);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE: Update a student record
router.put('/:rollno', async (req, res) => {
  try {
    const updated = await Student.findOneAndUpdate(
      { rollno: req.params.rollno },
        req.body,
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE: Delete a student 
router.delete('/:rollno', async (req, res) => {
  try {
    const result = await Student.findOneAndDelete({ rollno: req.params.rollno });
    if (!result) return res.status(404).json({ error: "Student not found" });
    res.json({ message: "Student deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
