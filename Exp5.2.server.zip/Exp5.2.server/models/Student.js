// import the mongoose module
const mongoose = require('mongoose');

// define schema for the Students collection (table)
const studentSchema = new mongoose.Schema({
  rollno: { type: Number, required: true, unique: true },
  name: { type: String, required: true },
  course: { type: String, required: true }
});

// define collection name to be created in MongoDB
module.exports = mongoose.model('Student', studentSchema);

