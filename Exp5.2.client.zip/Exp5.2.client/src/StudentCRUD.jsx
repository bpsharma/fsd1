import React, { useState, useEffect } from "react";
import axios from "axios";

export default function StudentCRUD() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ rollno: "", name: "", course: "" });
  const [editingRollno, setEditingRollno] = useState(null);

  // Fetch all students
  const fetchStudents = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/students");
      setStudents(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Create or Update student
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingRollno) {
        await axios.put(`http://localhost:5000/api/students/${editingRollno}`, form);
      } else {
        await axios.post("http://localhost:5000/api/students", form);
      }
      setForm({ rollno: "", name: "", course: "" });
      setEditingRollno(null);
      fetchStudents();
    } catch (err) {
      console.error(err);
    }
  };

  // Edit student
  const handleEdit = (student) => {
    setForm(student);
    setEditingRollno(student.rollno);
  };

  // Delete student
  const handleDelete = async (rollno) => {
    try {
      await axios.delete(`http://localhost:5000/api/students/${rollno}`);
      fetchStudents();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="p-4">
      <h2>Student CRUD Operations</h2>

      {/* Form */}
      <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
        <input
          type="text"
          name="rollno"
          placeholder="Roll No"
          value={form.rollno}
          onChange={handleChange}
          disabled={!!editingRollno} // cannot change rollno while editing
          required
        />
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="course"
          placeholder="Course"
          value={form.course}
          onChange={handleChange}
          required
        />
        <button type="submit">{editingRollno ? "Update" : "Add"}</button>
        {editingRollno && (
          <button type="button" onClick={() => { setForm({ rollno: "", name: "", course: "" }); setEditingRollno(null); }}>
            Cancel
          </button>
        )}
      </form>

      {/* Student List */}
      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>Roll No</th>
            <th>Name</th>
            <th>Course</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((s) => (
            <tr key={s.rollno}>
              <td>{s.rollno}</td>
              <td>{s.name}</td>
              <td>{s.course}</td>
              <td>
                <button onClick={() => handleEdit(s)}>Edit</button>
                <button onClick={() => handleDelete(s.rollno)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
